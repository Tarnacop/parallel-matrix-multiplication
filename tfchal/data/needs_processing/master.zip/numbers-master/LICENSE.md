The License
===========

*You can copy, modify, distribute and perform the work, even for commercial purposes, all without asking permission.*

The author has dedicated this repository to the **public domain** by
waiving all of his rights to the work worldwide under copyright law,
including all related and neighboring rights, to the extent allowed by
law.

The legal text:
[CC0 1.0 Universal](http://creativecommons.org/publicdomain/zero/1.0/),
the Public Domain Dedication (CC0 1.0).

Some context:
[Public Domain Software](https://en.wikipedia.org/wiki/Public_domain_software).
