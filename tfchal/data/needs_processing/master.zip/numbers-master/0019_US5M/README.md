This set of numbers has the "American" digits for 1 and 7.
